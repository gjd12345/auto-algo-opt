"""Frozen benchmark data manifests."""
