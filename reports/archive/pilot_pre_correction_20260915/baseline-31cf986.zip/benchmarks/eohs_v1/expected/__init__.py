"""Frozen expected calibration artifacts."""
