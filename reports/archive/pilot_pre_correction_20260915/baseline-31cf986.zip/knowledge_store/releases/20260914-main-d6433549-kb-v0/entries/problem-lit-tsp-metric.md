# Metric TSP (literature secondary)

Secondary literature variant, not a new registered EoH problem_id.

## 定义或方法步骤

Distances satisfy the triangle inequality.

Catalog search query: `metric TSP approximation Christofides nearest neighbor`.

## 适用条件、假设与限制

Parent family `tsp`. eoh_map=possible/next_node_score.

Do not treat this card as a new evaluator interface.

## 来源及支持的具体结论

Catalog-defined variant. Method conclusions live on the screened method cards.

## 代码和评测关联

Target heuristics (search hints only): Nearest Neighbor (next_node_score), Christofides (not_mappable).

## 未确认项与冲突证据

No suite/metric/budget. Empty until a screened method is attached.
